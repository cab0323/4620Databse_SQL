-- Christian Cabrera

USE Pizzeria;

SELECT * FROM basepizza;

SELECT * FROM createdpizza;

SELECT * FROM dineinorder;

SELECT * FROM dineoutorder;

SELECT * FROM discount;

SELECT * FROM finalpizza;

SELECT * FROM pizzatopping;

SELECT * FROM savedcustomer;

SELECT * FROM seat;

SELECT * FROM topping;

SELECT * FROM pizzatopping;

SELECT * FROM request;

SELECT * FROM seat;

SELECT * FROM topping;
