-- Christian Cabrera

USE Pizzeria;

DROP TABLE seat;

DROP TABLE dineinorder;

DROP TABLE dineoutorder;

DROP TABLE finalpizza;

DROP TABLE foodrequest;

DROP TABLE pizzatopping;

DROP TABLE createdpizza;

DROP TABLE topping;

DROP TABLE discount;
 
DROP TABLE basepizza;

DROP TABLE savedcustomer;

